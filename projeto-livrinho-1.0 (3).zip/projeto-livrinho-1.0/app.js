const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const sequelize = require('./database');
const Usuario = require('./models/Usuario');
const bcrypt = require("bcryptjs");

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: false }));

app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

sequelize.sync({ force: false }).then(() => {
  console.log('Database synced!');
});

const session = require("express-session");


app.use(session({
  secret: "1234", 
  resave: false,
  saveUninitialized: false,
}));



app.get("/login", (req, res) => {
  res.render("login");
});


app.post("/login", async (req, res) => {
  const { login, senha } = req.body;
  const usuario = await Usuario.findOne({ where: { login } });

  if (!usuario) {
    return res.render("login", { error: "Usuário não encontrado!" });
  }

  // Comparar senha digitada com a senha criptografada do banco
  const senhaValida = await bcrypt.compare(senha, usuario.senha);

  if (!senhaValida) {
    return res.render("login", { error: "Senha incorreta!" });
  }

  // Criar sessão do usuário
  req.session.usuarioId = usuario.id;
  req.session.usuarioLogin = usuario.login;

  res.redirect("/");
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/login");
});


const autenticado = (req, res, next) => {
  if (!req.session.usuarioId) {
    return res.redirect("/login");
  }
  next();
};


//---------------//------------//-----------//----------//------------//-------------//--------//-------------//
app.get('/rotas', async (req, res) => {
  res.render('rotas')
})

app.get('/', async (req, res) => {
  res.render('index', { usuarioLogin: req.session.usuarioLogin });
});


app.get('/listar_usuario', async (req, res) => {
  let usuarios = await Usuario.findAll();
  usuarios = usuarios.map((usuario) => usuario.dataValues);
  
  res.render('listar_usuario', { usuarios });
});

app.get('/cadastrar_usuario', (req, res) => {
  res.render('cadastrar_usuario');
});

app.post('/cadastrar_usuario', async (req, res) => {
  const { login, senha } = req.body;
  await Usuario.create({ login, senha });
  res.redirect('/');
});

app.get('/editar_usuario/:id', async (req, res) => {
  let usuario = await Usuario.findByPk(req.params.id);
  usuario = usuario.dataValues;
  
  res.render('editar_usuario', { usuario });
});

app.post('/editar_usuario/:id', async (req, res) => {
  const { login, senha } = req.body;
  await Usuario.update({ login, senha }, { where: { id: req.params.id } });
  res.redirect('/');
});

app.get('/delete/:id', async (req, res) => {
  await Usuario.destroy({ where: { id: req.params.id } });
  res.redirect('/');
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
