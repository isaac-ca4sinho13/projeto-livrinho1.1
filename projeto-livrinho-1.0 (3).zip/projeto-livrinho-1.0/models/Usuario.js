const { DataTypes } = require('sequelize');
const sequelize = require('../database');
const bcrypt = require("bcryptjs");

const Usuario = sequelize.define('Usuario', {
  login: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  senha: {
    type: DataTypes.STRING,
    allowNull: false,
  },
});

Usuario.beforeCreate(async (usuario) => {
  const salt = await bcrypt.genSalt(10);
  usuario.senha = await bcrypt.hash(usuario.senha, salt);
});

module.exports = Usuario;
