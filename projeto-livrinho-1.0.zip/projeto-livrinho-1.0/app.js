const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const sequelize = require('./database');
const bcrypt = require("bcryptjs");


const Usuario = require('./models/Usuario');
const Livro = require('./models/Livro')
const Emprestimo = require('./models/Emprestimo')
const Devolucao = require('./models/Devolucao')

const app = express();
const PORT = 3000;


const Handlebars = require("handlebars");

Handlebars.registerHelper("formatDate", function (dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString("pt-BR");
});




app.use(bodyParser.urlencoded({ extended: false }));

app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

sequelize.sync({ force: false }).then(() => {
  console.log('Database synced!');
});

const session = require("express-session");


app.use(session({
  secret: "1234", 
  resave: false,
  saveUninitialized: false,
}));

const path = require('path');
app.use(express.static(path.join(__dirname, 'public')));



app.get("/login", (req, res) => {
  res.render("login");
});


app.post("/login", async (req, res) => {
  const { login, senha } = req.body;
  const usuario = await Usuario.findOne({ where: { login } });

  if (!usuario) {
    return res.render("login", { error: "Usuário não encontrado!" });
  }

 
  const senhaValida = await bcrypt.compare(senha, usuario.senha);

  if (!senhaValida) {
    return res.render("login", { error: "Senha incorreta!" });
  }

  req.session.usuarioId = usuario.id;
  req.session.usuarioLogin = usuario.login;

  res.redirect("/");
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/login");
});


const autenticado = (req, res, next) => {
  if (!req.session.usuarioId) {
    return res.redirect("/login");
  }
  next();
};


//---------------//------------//-----------//----------//------------//-------------//--------//-------------//
app.get('/rotas', async (req, res) => {
  res.render('rotas')
})

app.get('/', async (req, res) => {
  res.render('index', { usuarioLogin: req.session.usuarioLogin , css:"public/css/cadastro.css" });
});


app.get('/listar_usuario', async (req, res) => {
  let usuarios = await Usuario.findAll();
  usuarios = usuarios.map((usuario) => usuario.dataValues);
  
  res.render('listar_usuario', { usuarios });
});

app.get('/cadastrar_usuario', (req, res) => {
  res.render('cadastrar_usuario',  {css:"public/css/cadastro.css" });
});

app.post('/cadastrar_usuario', async (req, res) => {
  try {
    const { login, senha } = req.body;

    // Verificar se o login já existe
    const usuarioExistente = await Usuario.findOne({ where: { login } });

    if (usuarioExistente) {
      return res.render('cadastrar_usuario', { error: 'Este login já está em uso. Escolha outro!' });
    }

    // Criar novo usuário se o login não existir
    await Usuario.create({ login, senha });

    res.redirect('/');
  } catch (error) {
    console.error(error);
    res.status(500).render('cadastrar_usuario', { error: 'Erro ao cadastrar usuário.' });
  }
});


app.get('/editar_usuario/:id', async (req, res) => {
  const usuarioId = req.params.id;
  const usuario = await Usuario.findByPk(usuarioId);
  res.render('editar_usuario', { usuario: usuario.dataValues });
});

app.post('/editar_usuario/:id', async (req, res) => {
  const { login, senha } = req.body;
  await Usuario.update({ login, senha }, { where: { id: req.params.id } });
  res.redirect('/');
});

app.get('/delete/:id', async (req, res) => {
  await Usuario.destroy({ where: { id: req.params.id } });
  res.redirect('/listar_usuario');
});


//--------//-----------//--------Livros-------//---------------//-----------//
app.get("/cadastrar_livro", async (req,res) => {
  res.render('cadastrar_livro', { css: "public/css/cadastro.css" });
  });
  

app.get('/listar_livro', async (req, res) => {
  let livros = await Livro.findAll();
  livros = livros.map((livro) => livro.dataValues);
  
  res.render('listar_livro', { livros , css:"public/css/cadastro.css" });
});

app.post('/cadastrar_livro', async (req, res) => {
  const { nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade } = req.body;
  await Livro.create({ nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade });
  res.redirect('/');
});


app.get('/editar_livro/:id', async (req, res) => {
  const livroid = req.params.id;
  const livro = await Livro.findByPk(livroid);
  res.render('editar_livro', { livro: livro.dataValues , css: 'public/css/cadastro.css' });
});


app.post('/editar_livro/:id', async (req, res) => {
  const { nome, autor, genero, ano_lanc, qtd_paginas, pais_origem } = req.body;
  await Livro.update({nome, autor, genero, ano_lanc, qtd_paginas, pais_origem }, { where: { id: req.params.id } });
  res.redirect('/');
});


app.get('/deletar_livro/:id', async (req, res) => {
  await Livro.destroy({ where: { id: req.params.id } });
  res.redirect('/listar_livro');
});


//----------------------Empréstimos------------------------------------------//
app.get("/cadastrar_emprestimo", async (req,res) => {
  res.render('cadastrar_emprestimo', { css: "public/css/cadastro.css" });
  });


app.post('/cadastrar_emprestimo', async (req, res) => {
  const { nome, nome_aluno, dataantes} = req.body
  const data = new Date(dataantes);
  await Emprestimo.create({ nome, nome_aluno, data});
  res.redirect('/listar_emprestimo');
});


app.get('/listar_emprestimo', async (req, res) => {
  let emprestimos = await Emprestimo.findAll();
  
  emprestimos = emprestimos.map((emprestimo) => emprestimo.dataValues);
  res.render('listar_emprestimo', { emprestimos ,  css: "public/css/cadastro.css"} );
});



//----------------------Devoluções------------------------------------------//



app.get("/cadastrar_devolucao", async (req,res) => {
  res.render('cadastrar_devolucao', { css: "public/css/cadastro.css" });
  });


app.post('/cadastrar_devolucao', async (req, res) => {
  const { nome, nome_aluno, dataantes, danificado, taxa} = req.body
  const data = new Date(dataantes);
  const danificadoBoolean = danificado === 'true';
  await Devolucao.create({ nome, nome_aluno, data, danificado: danificadoBoolean, taxa});
  res.redirect('/listar_devolucao');
});


app.get('/listar_devolucao', async (req, res) => {
  let devolucoes = await Devolucao.findAll();
  
  devolucoes = devolucoes.map((devolucao) => devolucao.dataValues);
  res.render('listar_devolucao', { devolucoes ,  css: "public/css/cadastro.css"} );
});


















app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
