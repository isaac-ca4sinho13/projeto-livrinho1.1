const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Devolucao = sequelize.define('Devolucao', {
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  nome_aluno: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  data: {
    type: DataTypes.DATE,
    allowNull: false,
  },
  danificado: {
    type: DataTypes.BOOLEAN,
    allowNull: false,
  },
  taxa: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});


module.exports = Devolucao;
