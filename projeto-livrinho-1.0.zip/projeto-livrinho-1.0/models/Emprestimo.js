const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Emprestimo = sequelize.define('Emprestimo', {
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  nome_aluno: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  data: {
    type: DataTypes.DATE,
    allowNull: false,
  },
});


module.exports = Emprestimo;
