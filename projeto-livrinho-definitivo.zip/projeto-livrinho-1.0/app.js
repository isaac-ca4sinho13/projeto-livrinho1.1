const express = require('express');
const bodyParser = require('body-parser');
const exphbs = require('express-handlebars');
const sequelize = require('./database');
const bcrypt = require("bcryptjs");

const Usuario = require('./models/Usuario');
const Livro = require('./models/Livro')
const Lista_livro = require('./models/Lista_livro')

const app = express();
const PORT = 3000;

app.use(bodyParser.urlencoded({ extended: false }));

app.engine('handlebars', exphbs.engine());
app.set('view engine', 'handlebars');

sequelize.sync({ force: false }).then(() => {
  console.log('Database synced!');
});

const session = require("express-session");


app.use(session({
  secret: "1234", 
  resave: false,
  saveUninitialized: false,
}));



app.get("/login", (req, res) => {
  res.render("login");
});


app.post("/login", async (req, res) => {
  const { login, senha } = req.body;
  const usuario = await Usuario.findOne({ where: { login } });

  if (!usuario) {
    return res.render("login", { error: "Usuário não encontrado!" });
  }

 
  const senhaValida = await bcrypt.compare(senha, usuario.senha);

  if (!senhaValida) {
    return res.render("login", { error: "Senha incorreta!" });
  }

  req.session.usuarioId = usuario.id;
  req.session.usuarioLogin = usuario.login;

  res.redirect("/");
});

// Logout
app.get("/logout", (req, res) => {
  req.session.destroy();
  res.redirect("/login");
});


const autenticado = (req, res, next) => {
  if (!req.session.usuarioId) {
    return res.redirect("/login");
  }
  next();
};


//---------------//------------//-----------//----------//------------//-------------//--------//-------------//
app.get('/rotas', async (req, res) => {
  res.render('rotas')
})

app.get('/', async (req, res) => {
  res.render('index', { usuarioLogin: req.session.usuarioLogin });
});


app.get('/listar_usuario', async (req, res) => {
  let usuarios = await Usuario.findAll();
  usuarios = usuarios.map((usuario) => usuario.dataValues);
  
  res.render('listar_usuario', { usuarios });
});

app.get('/cadastrar_usuario', (req, res) => {
  res.render('cadastrar_usuario');
});

app.post('/cadastrar_usuario', async (req, res) => {
  const { login, senha } = req.body;
  await Usuario.create({ login, senha });
  res.redirect('/');
});

app.get('/editar_usuario/:id', async (req, res) => {
  const usuarioId = req.params.id;
  const usuario = await Usuario.findByPk(usuarioId);
  res.render('editar_usuario', { usuario: usuario.dataValues });
});

app.post('/editar_usuario/:id', async (req, res) => {
  const { login, senha } = req.body;
  await Usuario.update({ login, senha }, { where: { id: req.params.id } });
  res.redirect('/');
});

app.get('/delete/:id', async (req, res) => {
  await Usuario.destroy({ where: { id: req.params.id } });
  res.redirect('/listar_usuario');
});


//--------//-----------//--------Livros-------//---------------//-----------//
app.get("/cadastrar_livro", async (req,res) => {
  res.render('cadastrar_livro')
})

app.get('/listar_livro', async (req, res) => {
  let livros = await Livro.findAll();
  livros = livros.map((livro) => livro.dataValues);
  
  res.render('listar_livro', { livros });
});

app.post('/cadastrar_livro', async (req, res) => {
  const { nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade } = req.body;
  await Livro.create({ nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade });
  res.redirect('/');
});


app.get('/editar_livro/:id', async (req, res) => {
  const livroid = req.params.id;
  const livro = await Livro.findByPk(livroid);
  res.render('editar_livro', { livro: livro.dataValues });
});


app.post('/editar_livro/:id', async (req, res) => {
  const { nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade } = req.body;
  await Usuario.update({nome, autor, genero, ano_lanc, qtd_paginas, pais_origem, quantidade }, { where: { id: req.params.id } });
  res.redirect('/');
});





//----------------------lista livros------------------------------------------//




app.post('/adicionar-livro', async (req, res) => {
  try {
    const { usuarioId, livroId } = req.body;

    const existe = await Lista_livro.findOne({ where: { usuarioId, livroId } });

    if (existe) {
      return res.status(400).json({ message: 'Livro já está na sua lista' });
    }

    await Lista_livro.create({ usuarioId, livroId });

    res.redirect('/minha-lista'); 
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao adicionar livro' });
  }
});



app.get('/minha-lista/:id', async (req, res) => {
  try {
    const { id } = req.params;

    const lista = await Lista_livro.findAll({
      where: { id },
      include: [{ model: Livro }]
    });

    res.render('favoritos', { livros: lista });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Erro ao buscar lista' });
  }
});
















app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
