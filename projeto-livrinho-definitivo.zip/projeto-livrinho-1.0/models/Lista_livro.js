const { DataTypes } = require('sequelize');
const sequelize = require('../database');
const Livro = require('./Livro');
const Usuario = require('./Usuario'); // Se tiver um modelo de usuário

const ListaLivro = sequelize.define('ListaLivro', {
  usuarioId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
  livroId: {
    type: DataTypes.INTEGER,
    allowNull: false,
  }
});

ListaLivro.belongsTo(Livro, { foreignKey: 'id' });
ListaLivro.belongsTo(Usuario, { foreignKey: 'id' });

module.exports = ListaLivro;
