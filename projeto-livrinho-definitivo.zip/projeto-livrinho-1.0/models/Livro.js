const { DataTypes } = require('sequelize');
const sequelize = require('../database');

const Livro = sequelize.define('Livro', {
  nome: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  autor: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  genero: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  ano_lanc: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  qtd_paginas: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  pais_origem: {
    type: DataTypes.STRING,
    allowNull: false,
  },
  quantidade: {
    type: DataTypes.INTEGER,
    allowNull: false,
  },
});


module.exports = Livro;
